=== Tekserve Rentals ===
Contributors: bangerkuwranger
Tags: rental,equipment,checkout
Donate link: http://www.chadacarino.com/burnallmoney.html
Requires at least: 3.8
Tested up to: 3.9.1
Stable tag: 1.2
License: MIT
License URI: http://www.chadacarino.com/license-mit.html

Enables a rentals system, complete with individual skus and rates.