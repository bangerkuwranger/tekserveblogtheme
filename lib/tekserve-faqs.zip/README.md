tekserve_faqs
=============

faq plugin for wordpress - automatically sets issues and connects to MOST OS/Devices based on category

How To Set Up Automatic Issues
------------------------------

* Go to Posts>Issue
* For each issue, create a New Issue
* Edit the Issue and select related Categories
* Any post saved with these Categories will automatically have the Issue added

How to Set Up Automatic OS / Device Connections
------------------------------

* Go to the OS or Device you would like to be set automatically
* Add the Categories that you would like to use to automatically connect its posts to
* When saving a Post, if it is in one of those Categories, it will automatically connect to that OS or Device