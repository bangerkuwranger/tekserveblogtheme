tekserve-ga-events
==================

Allows you to set certain Google Analytics events to be triggered by a selector.
