CSSTidy

Changelog: http://cdburnerxp.se/cssparse/csstidy/changelog.php

css_optimiser.php is the web-interface, css_parser.php contains the PHP class (CSSTidy).

This class represents a CSS parser which reads CSS code and saves it in an array.
In opposite to most other CSS parsers, it does not use regular expressions and
thus has full CSS2 support and a higher reliability. The downside of not using regular expressions
is a lower speed though.
Additional to that it applies some optimisations and fixes to the CSS code.
An online version should be available here: http://cdburnerxp.se/cssparse/css_optimiser.php



CSSTidy is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

CSSTidy is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with CSSTidy; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
