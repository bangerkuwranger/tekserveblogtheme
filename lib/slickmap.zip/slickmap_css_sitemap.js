jQuery(document).ready(function ($) {
	 $('.iris-color-picker-field').wpColorPicker();
});