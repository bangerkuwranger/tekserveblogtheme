jQuery(document).ready(function () {
	 jQuery('.iris-color-picker-field').wpColorPicker();
});